<?php 
$cari=$_GET['cari'];
header("location:produk.php?cari=$cari");
?>