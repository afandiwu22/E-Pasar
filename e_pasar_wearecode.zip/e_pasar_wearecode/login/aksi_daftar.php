<?php 
session_start();
include '../config.php';

$nama = $_POST['nama'];
$email = $_POST['email'];
$nohp = $_POST['nohp'];
$uname = $_POST['uname'];
$pass = $_POST['pass'];
$alamat = $_POST['alamat'];

$tanggal = date("Y-m-d H:i:s");


$daftaru = mysqli_query($link,"Insert Into user VALUES ('', '".$nama."', '".$alamat."', '".$email."', '".$nohp."', '".$uname."', '".$pass."',  '".$tanggal."')");

if($daftaru){


$login = mysqli_query($link,"SELECT * FROM login WHERE username = '$uname' AND password='$pass'");
$row=mysqli_fetch_array($login);
if ($row['username'] == $uname AND $row['password'] == $pass)
{
  session_start();
  $_SESSION['username'] = $row['username'];
  $_SESSION['password'] = $row['password'];
  header('location:../jual/index.php');
}


}else{
	header("location:login.php?pesan=gagal");


}





 ?>
