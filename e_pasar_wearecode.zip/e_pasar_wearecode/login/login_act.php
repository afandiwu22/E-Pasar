<?php 
session_start();
include '../config.php';
$uname=$_POST['uname'];
$pass=$_POST['pass'];
$admin = "admin";

$login = mysqli_query($link,"SELECT * FROM login WHERE username = '$uname' ");
$row=mysqli_fetch_array($login);

if($row['as'] == "admin")
{


      if($row['username'] == $uname AND $row['password'] == $pass)
      {
        session_start();
        $_SESSION['username'] = $row['username'];
        $_SESSION['password'] = $row['password'];
          header('location:../admin/home_admin.php');
      }else{
        header("location:login.php?pesan=gagal");
      }

}else{

      if($row['username'] == $uname AND $row['password'] == $pass)
      {
        session_start();
        $_SESSION['username'] = $row['username'];
        $_SESSION['password'] = $row['password'];
          header('location:../jual/index.php');
      }else if($row['username'] == $uname AND $row['password'] == "hapususer00")
      {
        header("location:login.php?pesan=hapus");
      }

      else{
        header("location:login.php?pesan=gagal");
      }

}






 ?>
