  <?php include'header.php';?>


    <div class="hero-wrap hero-bread" style="background-image: url('images/bg_1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-0 bread">Detail Produk</h1>
          </div>
        </div>
      </div>
    </div>

    <?php
$id_brg=mysqli_real_escape_string($link,$_GET['id']);

$det=mysqli_query($link,"select * from barang where id_barang='$id_brg' ");
while($d=mysqli_fetch_array($det)){
  ?>  


    <section class="ftco-section">
    	<div class="container">
        <a href="produk.php"> <span class="icon icon-arrow-left"> </span> Kembali </a>
    		<div class="row">
    			<div class="col-lg-6 mb-5 ftco-animate">
    				<a href="foto/<?php echo $d['foto_barang'];?>" class="image-popup"><img src="foto/<?php echo $d['foto_barang'];?>" class="img-fluid" ></a>
    			</div>
    			<div class="col-lg-6 product-details pl-md-5 ftco-animate">
    				<h3><?php echo $d['nama_barang'] ?></h3>

            <h5><?php echo $d['jenis_barang'] ?></h5>
    				<p class="price"><span>Rp.<?php echo number_format($d['harga_barang']) ?></span></p>
    				<p><?php echo $d['ket_barang'] ?></p>

        					
							
	           
	          	<div class="col-md-12">
	          		<p style="color: #000;">Stok : <?php echo $d['quantity_barang'] ?> Kg</p>
	          	</div>
          	</div>
    			</div>
    		</div>
    	</div>
    </section>


<?php
}
?>










































  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/bootstrap-datepicker.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  
  </body>
</html>