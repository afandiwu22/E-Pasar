-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 11, 2019 at 05:31 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pasar`
--

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `foto_barang` varchar(1000) NOT NULL,
  `nama_barang` varchar(100) NOT NULL,
  `jenis_barang` varchar(100) NOT NULL,
  `quantity_barang` int(11) NOT NULL,
  `harga_barang` int(11) NOT NULL,
  `ket_barang` text NOT NULL,
  `waktu_input` datetime NOT NULL,
  `nama_input` varchar(100) NOT NULL,
  `waktu_edit` datetime NOT NULL,
  `nama_edit` varchar(100) NOT NULL,
  `kep` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `foto_barang`, `nama_barang`, `jenis_barang`, `quantity_barang`, `harga_barang`, `ket_barang`, `waktu_input`, `nama_input`, `waktu_edit`, `nama_edit`, `kep`) VALUES
(36, 'chicken.png', 'ayam', 'Daging', 20, 10000, 'bagus', '2019-11-28 19:27:12', 'afandiwu_', '0000-00-00 00:00:00', '', 'acc'),
(38, 'sawi.png', 'sawi', 'Ikan', 93, 2500, 'Bagus', '2019-11-21 13:46:46', 'afandiwu_', '0000-00-00 00:00:00', '', 'acc'),
(47, 'fotobarang47.jpg', 'Strwaberry', 'Buah', 100, 10500, 'Segar Habis', '2019-12-09 11:09:13', 'afandiwu_', '0000-00-00 00:00:00', '', 'proses'),
(48, 'fotobarang48.png', 'Jagung', 'Sayur', 100, 5000, 'Segar dari kebun', '2019-12-10 12:40:09', 'afandiwu_', '0000-00-00 00:00:00', '', 'proses'),
(49, 'fotobarang49.png', 'Ikan Tuna', 'Ikan', 20, 200000, 'Segar Dari laut', '2019-12-10 12:40:36', 'afandiwu_', '0000-00-00 00:00:00', '', 'proses'),
(51, 'fotobarang51.png', 'Jeruk', 'Buah', 100, 25000, 'bagus', '2019-12-10 15:12:05', 'afandiwu_', '0000-00-00 00:00:00', '', 'proses'),
(52, 'fotobarang52.jpg', 'Buah', 'Buah', 46, 3536, 'Good Quality', '2019-12-10 15:13:03', 'afandiwu_', '0000-00-00 00:00:00', '', 'proses');

-- --------------------------------------------------------

--
-- Table structure for table `keranjang`
--

CREATE TABLE `keranjang` (
  `id_keranjang` int(11) NOT NULL,
  `id_barang` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `quantity_barang` int(11) NOT NULL,
  `total_barang` int(11) NOT NULL,
  `ket_k` varchar(100) NOT NULL,
  `username_jual` varchar(100) NOT NULL,
  `tanggal` datetime NOT NULL,
  `tanggal_edit` datetime NOT NULL,
  `komentar` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `keranjang`
--

INSERT INTO `keranjang` (`id_keranjang`, `id_barang`, `username`, `quantity_barang`, `total_barang`, `ket_k`, `username_jual`, `tanggal`, `tanggal_edit`, `komentar`) VALUES
(28, '37', 'budi', 3, 7500, 'krm', 'afandiwu_', '2019-12-07 18:43:28', '0000-00-00 00:00:00', ''),
(29, '36', 'budi', 3, 30000, 'krm', 'afandiwu_', '2019-12-07 18:43:31', '0000-00-00 00:00:00', ''),
(30, '38', 'hello', 4, 10000, 'krm', 'afandiwu_', '2019-12-10 13:58:14', '0000-00-00 00:00:00', ''),
(31, '50', 'hello', 1, 150000, 'bb', 'afandiwu_', '2019-12-10 14:03:40', '0000-00-00 00:00:00', ''),
(32, '49', 'hello', 1, 200000, 'bb', 'afandiwu_', '2019-12-10 14:03:46', '0000-00-00 00:00:00', ''),
(33, '47', 'hello', 1, 10500, 'bb', 'afandiwu_', '2019-12-10 14:03:55', '0000-00-00 00:00:00', '');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_login` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `as` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_login`, `username`, `password`, `as`) VALUES
(2, 'admin', 'admin123', 'admin'),
(5, 'afandiwu_', 'afandi1234', 'user'),
(6, 'budi', 'hapususer00', 'user'),
(7, 'hello', 'akjd', 'user');

--
-- Triggers `login`
--
DELIMITER $$
CREATE TRIGGER `ganti_psss` AFTER UPDATE ON `login` FOR EACH ROW UPDATE user SET password = new.password WHERE username = username
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `ttl` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `tanggal_daftar` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `nama`, `ttl`, `no_hp`, `email`, `username`, `password`, `tanggal_daftar`) VALUES
(4, 'Afandi', 'Komp Ruko Fanindo Blok P No 10-11', 'afandiwu22@gmai', '081267714878', 'afandiwu_', 'hapususer00', '2019-12-08 16:29:34'),
(5, 'budi', 'fanindi', 'budi@gmail.com', '0811771311', 'budi', 'hapususer00', '2019-12-08 16:23:45'),
(6, 'hello', 'aisjisjiajsaji', 'budi@gmail.com', '08123456789', 'hello', 'akjd', '2019-12-10 06:57:30');

--
-- Triggers `user`
--
DELIMITER $$
CREATE TRIGGER `inputlogin` AFTER INSERT ON `user` FOR EACH ROW INSERT into login VALUES ('',new.username, new.password, 'user')
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `keranjang`
--
ALTER TABLE `keranjang`
  ADD PRIMARY KEY (`id_keranjang`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_login`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `keranjang`
--
ALTER TABLE `keranjang`
  MODIFY `id_keranjang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
