<?php include'header.php';?>

<div class="container">
<h1> <span class="icon icon-plus"> </span> Tambah Produk </h1>
<div class="col-md-3">
	</div>
<div class="col-md-6">
<form action="tambah_barang_act.php" method="post" enctype="multipart/form-data">
	
	
	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;"><span class="icon icon-briefcase"></span></span>
		<input type="text" class="form-control" placeholder="Nama Barang" name="nama" required>
	</div>
	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;"><span class="icon icon-camera"></span></span>
		<input type="file" class="form-control" name="file" required>
	</div>
	
	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;">J</span>
		<select name="jenis" class="form-control" required>

			<option value="">--Pilih Jenis Barang--</option>
			<option value="Daging">Daging</option>
			<option value="Buah">Buah</option>
			<option value="Sayur">Sayur</option>
			<option value="Ikan">Ikan</option>
			<option value="lain">Lain-Lain</option>

			
		</select>
	</div>
	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;">Q</span>
		<input type="number" class="form-control" placeholder="Quantity" name="qty" required>
	</div>

	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;"> <span class="icon icon-dollar"> </span></span>
		<input type="number" class="form-control" placeholder="Harga Barang" name="harga" required>
	</div>

	<div class="input-group">
		<span class="input-group-addon" style="width: 50px;"> Ket</span>
		<input type="text" class="form-control" placeholder="Keterangan Baran" name="ket" required>
	</div>
	<div class="input-group">
		<center>
		<input type="submit" value="Tambah"  name="upload" class="btn btn-info"> 
	</center>
	</div>

	
					
</form>
</div>


</div>