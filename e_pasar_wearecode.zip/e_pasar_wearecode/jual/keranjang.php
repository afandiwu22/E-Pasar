  <?php include'header.php';?>

<?php 
	$username =  $_SESSION['username'] ;
		$ket = "bb";
    $brg=mysqli_query($link," SELECT barang.* , keranjang.* FROM keranjang JOIN barang ON barang.id_barang =keranjang.id_barang where ket_k ='$ket' AND username = '$username' ");
    $cek = mysqli_num_rows($brg);
  	$no=1;

  	if($cek >= 1){


?>
    

    <section class="ftco-section ftco-cart">
			<div class="container">
				<div class="row">
    			<div class="col-md-12 ftco-animate">
    				<div class="cart-list">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>&nbsp;</th>
						        <th>Toko</th>
						        <th>Gambar</th>
						        <th>Nama Barang</th>
						        <th>Harga</th>
						        <th>Banyak</th>
						        <th>Jumlah</th>
						      </tr>
						    </thead>
						    <tbody>



						    	<?php
    while($b=mysqli_fetch_array($brg)){

		?>

						      <tr class="text-center">
						        <td class="product-remove"> <a href="hapus_keranjang.php?id=<?php echo $b['id_keranjang'];?>"><span class="ion-ios-close"></span></a></td>
						        
						        <td><?php echo $b['username_jual'];?></td>
						        <td class="image-prod"><div class="img" style="background-image:url(../foto/<?php echo $b['foto_barang'];?>);"></div></td>
						        
						        <td class="product-name">
						        	<h3><?php echo $b['nama_barang'];?></h3>
						        	<p><?php  echo $b['ket_barang'];?></p>
						        </td>
						        
						        <td>Rp. <?php echo number_format($b['harga_barang']);?></td>

						        <td class="quantity">
						        	
					             	<a href="kurang_barang.php?id=<?php echo $b['id_keranjang'];?>" class="btn btn-primary" style=" height: 25px; font-size: 10px;"> <span class="glyphicon glyphicon-minus"></span> </a>

						<?php echo $b['quantity_barang'];?>

								 <a href="tambah_barang.php?id=<?php echo $b['id_keranjang'];?>" class="btn btn-primary" style=" height: 25px; font-size: 10px;"> <span class="glyphicon glyphicon-plus"></span> </a>



						    
					          </td>
						        
						        <td class="total">Rp.<?php echo number_format($b['total_barang']);?></td>
						     



						     <?php

						 }
						 ?>


</tr>
</tbody>


						 <tr>

						 	<?php


						 	  $brg1=mysqli_query($link," SELECT sum(total_barang)  as total_semua  FROM keranjang  where ket_k ='$ket' AND username = '$username' limit 1 ");
  	$no=1;
    while($c=mysqli_fetch_array($brg1)){

    	  $brg2=mysqli_query($link," SELECT username_jual FROM keranjang  where ket_k ='$ket' AND username = '$username' ");
    	$d=mysqli_num_rows($brg2);
    	?>

    	<td colspan="5">Total</td>
    	<td><b>Rp.<?php echo number_format($c['total_semua']);?> </b>	</td>


</tr>

		<tr>
	<td colspan="5">Ongkos</td>
    	<td><b>Rp.<?php echo number_format($d * 10000);?> </b>
    		

    	</td>
    	<td></td>

</tr>
<tr>
	<td colspan="5">Grand Total</td>
	<td>

		<b>Rp. 
		<?php







		echo number_format($c['total_semua'] + (10000 * $d));

		?>
	</b>
	</td>
</tr>

<tr>
	<td colspan="5"></td>
	<td>
	<a href="pesanan.php" class="btn btn-info"> Pesan </a>


	</td>
</tr>



						 </tr>
						    </tbody>
						  </table>
					  </div>
    			</div>
    		</div>
<?php

}

}else{
	?>
<h1 style="margin: 300 600 600 550; color:red;"> Tidak ada data ,<a href="produk.php"> Belanja yuk....</a></h1>
	<?php
}
?>

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>



  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="../js/google-map.js"></script>
  <script src="../js/main.js"></script>

  <script>
		
		/*$(document).ready(function(){

		var quantitiy=0;
		   $('.quantity-right-plus').click(function(e){
		        
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		            
		            $('#quantity').val(quantity + 1);

		          
		            // Increment
		        
		    });

		     $('.quantity-left-minus').click(function(e){
		        // Stop acting like a button
		        e.preventDefault();
		        // Get the field name
		        var quantity = parseInt($('#quantity').val());
		        
		        // If is not undefined
		      
		            // Increment
		            if(quantity>0){
		            $('#quantity').val(quantity - 1);
		            }
		    });
		    
		});
		*/
	</script>
    
  </body>
</html>