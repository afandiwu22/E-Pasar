<?php include '../config.php';

$id_keranjang = $_GET['id_keranjang'];
$ket = "krm";

$cek = mysqli_query($link, "select * from keranjang where id_keranjang='$id_keranjang'");
$rew = mysqli_fetch_array($cek);

$jml = $rew['quantity_barang'];
$id_barang = $rew['id_barang'];

$try = mysqli_query($link, "select * from barang where id_barang='$id_barang'");
$row = mysqli_fetch_array($try);

$jml_awal = $row['quantity_barang'];

$stk = $jml_awal - $jml ;

$query = mysqli_query($link, "update barang SET quantity_barang ='$stk' where id_barang='$id_barang' ");
$query1 = mysqli_query($link, "update keranjang SET ket_k ='$ket' where id_keranjang='$id_keranjang' ");
header("location:penjualan_saya.php");
?>