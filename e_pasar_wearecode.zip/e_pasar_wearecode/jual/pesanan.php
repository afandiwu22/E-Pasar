<?php 
session_start();
include '../config.php';
$ket_psn = "psn";
$ket_bb = "bb";

$query = mysqli_query($link, "UPDATE keranjang SET ket_k ='$ket_psn'  where  ket_k ='$ket_bb' ");
header("location:riwayat.php");


 ?>
