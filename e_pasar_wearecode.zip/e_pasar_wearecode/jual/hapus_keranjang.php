<?php
include '../config.php';

$id_keranjang = $_GET['id'];
$query = mysqli_query($link, "delete from keranjang where id_keranjang ='$id_keranjang' ");
header("location:keranjang.php");




?>
