<?php 
$cari=$_GET['cari'];
header("location:penjualan_saya.php?cari=$cari");
?>