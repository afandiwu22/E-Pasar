<?php include '../config.php';

$id_keranjang = $_POST['id'];
$ket = "sls";
$komentar = $_POST['komentar'];
$query = mysqli_query($link, "update keranjang SET ket_k ='$ket' , komentar ='$komentar' where id_keranjang='$id_keranjang' ");
header("location:riwayat.php");
?>