<?php
    include '../config.php';

$id_keranjang  = $_GET['id'];


$query=mysqli_query($link," SELECT * FROM keranjang where id_keranjang='$id_keranjang'");
 $b=mysqli_fetch_array($query);

$lama = $b['quantity_barang'];
$harga = $b['total_barang'] / $lama ;
 


$baru = $lama + 1 ;

$total_baru  = $baru * $harga ;


$query1 = mysqli_query($link, "update keranjang SET quantity_barang ='$baru' , total_barang ='$total_baru' WHERE id_keranjang = '$id_keranjang' ");

 header("location:keranjang.php");



