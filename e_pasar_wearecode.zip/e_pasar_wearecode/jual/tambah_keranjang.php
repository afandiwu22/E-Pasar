<?php 
session_start();
include '../config.php';

$jumlah_barang = 1;
$tanggal = date("Y-m-d H:i:s");
$username =  $_SESSION['username'];
$ket = "bb";
$id_barang = $_GET['id'];


$cek = mysqli_query($link,"select * from keranjang where id_barang ='$id_barang' AND username ='$username' AND ket_k ='$ket' ");
$cek1 = mysqli_num_rows($cek);
$tampil = mysqli_fetch_array($cek);

 $hrg = $tampil['total_barang'] / $tampil['quantity_barang'];

if($cek1 == "1"){

$qty_barang = $tampil['quantity_barang'] + 1;
$ttl = $hrg * $qty_barang;

$query = mysqli_query($link, "UPDATE keranjang SET quantity_barang ='$qty_barang' , total_barang = '$ttl' where id_barang ='$id_barang' and username ='$username' ");

echo "<script>alert('Berhasil Tambah');window.location='";
					echo header("location:produk.php");
					echo "';</script>";

}else{


$barang = mysqli_query($link, "select * from barang where id_barang ='$id_barang' ");
$row=mysqli_fetch_array($barang);

$harga_barang = $row['harga_barang'];
$nama_input = $row['nama_input'];
$total = $harga_barang * $jumlah_barang;





$daftar = mysqli_query($link,"Insert Into keranjang VALUES ('','".$id_barang."', '".$username."',  '".$jumlah_barang."', '".$total."', '".$ket."', '".$nama_input."',   '".$tanggal."', '' ,'')");

					echo "<script>alert('Berhasil Tambah');window.location='";
					echo header("location:produk.php");;
					echo "';</script>";

}
 ?>
