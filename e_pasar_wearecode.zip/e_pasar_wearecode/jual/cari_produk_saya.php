<?php 
$cari=$_GET['cari'];
header("location:produk_saya.php?cari=$cari");
?>