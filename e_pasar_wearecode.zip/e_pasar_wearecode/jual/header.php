
<html lang="en">
  <head>
    <?php include'../config.php';
    session_start();
?>


    <title>E-pasar</title>
    
    <link href="../https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800&display=swap" rel="stylesheet">
    <link href="../https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i&display=swap" rel="stylesheet">
    <link href="../https://fonts.googleapis.com/css?family=Amatic+SC:400,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="../css/css_sendiri/bootstrap.css">

    <link rel="stylesheet" href="../css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="../css/animate.css">
    
    <link rel="stylesheet" href="../css/owl.carousel.min.css">
    <link rel="stylesheet" href="../css/owl.theme.default.min.css">
    <link rel="stylesheet" href="../css/magnific-popup.css">

    <link rel="stylesheet" href="../css/aos.css">


    <link rel="shortcut icon" href="../logo/logo.png">
    <link rel="stylesheet" href="../css/ionicons.min.css">

    <link rel="stylesheet" href="../css/bootstrap-datepicker.css">
    <link rel="stylesheet" href="../css/jquery.timepicker.css">

    
    <link rel="stylesheet" href="../css/flaticon.css">
    <link rel="stylesheet" href="../css/icomoon.css">
    <link rel="stylesheet" href="../css/style.css">
  </head>
  <body class="goto-here">
    <div class="py-1 bg-primary">

    </div>
<?php
$username = $_SESSION['username'];
$ket = "bb";

$query = mysqli_query($link,"select * from keranjang where username = '$username' AND ket_k ='$ket' ");
$row = mysqli_num_rows($query);
?>


    <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar" style="margin-bottom: 0;">
      <div class="container">
        <a class="navbar-brand" href="index.php">E-pasar</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active"><a href="index.php" class="nav-link">Beranda</a></li>

            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="" id="dropdown04" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Produk</a>
              <div class="dropdown-menu" aria-labelledby="dropdown04">
                <a class="dropdown-item" href="produk.php">Produk</a>
                <!--<a class="dropdown-item" href="wishlist.php">Wishlist</a>-->
                <a class="dropdown-item" href="Keranjang.php">Keranjang</a>
                <a class="dropdown-item" href="riwayat.php">Riwayat Belanja</a>
                <a class="dropdown-item" href="produk_saya.php" style="color: red;">Produk Saya</a>
                <a class="dropdown-item" href="penjualan_saya.php" style="color: red;">Penjualan Saya</a>

              </div>
            </li>
            <li class="nav-item"><a href="about.php" class="nav-link">Tentang</a></li>
            <li class="nav-item"><a href="contact.php" class="nav-link">Kontak</a></li>
            <li class="nav-item cta cta-colored"><a href="keranjang.php" class="nav-link"><span class="icon-shopping_cart"></span>[<?php echo $row;?>]</a></li>


            <li class="nav-item dropdown" style="margin-left: 150px;">
              <a class="nav-link dropdown-toggle" href="#" id="dropdown05" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['username'] ;?></a>
              <div class="dropdown-menu" aria-labelledby="dropdown05">
                  <a href="" class="dropdown-item"></a>

                 <a  href="ganti_sandi.php" class="dropdown-item" style="color:blue;">Ganti Kata Sandi</a>
                <!--<a class="dropdown-item" href="wishlist.php">Wishlist</a>-->
                <a class="dropdown-item" href="../index.php" style="color:red;">Keluar</a>
              </div>
            </li>



          </ul>
        </div>
      </div>
    </nav>


     <div class="py-1 bg-primary">

    </div>
    <!-- END nav -->
