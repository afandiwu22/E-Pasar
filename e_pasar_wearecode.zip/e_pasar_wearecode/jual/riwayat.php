<?php include'header.php';?>


<div class="container">
<h3 style="font-family:fantasy;"> Riwayat Belanja </h3>
	<div class="">
<a href="cari_kirim.php?cari=psn" > Perlu Kirim </a> | <a href="cari_kirim.php?cari=krm" >  Sedang Dikirim  </a> | <a href=" cari_kirim.php?cari=sls" >  Sudah Selesai </a>
	</div>
				<div class="row" style="margin-top: 10px;">
    			<div class="col-md-12">
    				<h1> 

    				<?php    			
if(isset($_GET['cari'])){
	    $cari=mysqli_real_escape_string($link,$_GET['cari']);
	    if($cari =="psn"){
	    	echo "Dikemas";
	    }else if($cari =="krm"){
	    	echo "Dikirim";
	    }else if($cari =="sls"){
	    	echo "Selesai";
	    }
	}else{
	    	echo "Dikemas";
	    
	}
	    ?>
    				 </h1>
    				<div class="cart-list">
	    				<table class="table">
						    <thead class="thead-primary">
						      <tr class="text-center">
						        <th>Toko</th>
						        <th>Gambar</th>
						        <th>Nama Barang</th>
						        <th>Harga</th>
						        <th>Banyak</th>
						        <th>Jumlah</th>
						        <th>Aksi</th>
						      </tr>
						    </thead>
						    <tbody>



						    	<?php
		
		$username =  $_SESSION['username'] ;

		$no =1;
		$ket ="psn";
if(isset($_GET['cari'])){
    $cari=mysqli_real_escape_string($link,$_GET['cari']);
    $brg=mysqli_query($link," SELECT barang.* , keranjang.* FROM keranjang JOIN barang ON barang.id_barang =keranjang.id_barang where  username = '$username' AND  ket_k = '$cari' ");
  }else{
   
    $brg=mysqli_query($link," SELECT barang.* , keranjang.* FROM keranjang JOIN barang ON barang.id_barang =keranjang.id_barang where ket_k ='$ket' AND username = '$username' ");
  	
  }
    while($b=mysqli_fetch_array($brg)){

		?>

						      <tr class="text-center">
						        
						        
						        <td><?php echo $b['username_jual'];?></td>
						        <td class="image-prod"><div class="img" style="background-image:url(../foto/<?php echo $b['foto_barang'];?>);"></div></td>
						        
						        <td class="product-name">
						        	<h3><?php echo $b['nama_barang'];?></h3>
						        	<p><?php  echo $b['ket_barang'];?></p>
						        </td>
						        
						        <td>Rp. <?php echo number_format($b['harga_barang']);?></td>

						        <td class="quantity">
						        	
					             	

						<?php echo $b['quantity_barang'];?>

								



						    
					          </td>
						        
						        <td class="total">Rp.<?php echo number_format($b['total_barang']);?></td>
						     


						        <td>
						        		<?php 
						        		$try = $b['ket_k'];

						        		if($try == "krm"){
						        			?>
						        			<a href="barang_terima.php?id_keranjang=<?php echo $b['id_keranjang']; ?>"  class="btn btn-info">Barang Diterima</a>
						        			<?php


						        		}

?>
						        </td>
						     <?php

						 }
						 ?>


</tr>
</tbody>
</table>
</div>
</div>








<div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>



  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="../js/google-map.js"></script>
  <script src="../js/main.js"></script>

  <script>
		