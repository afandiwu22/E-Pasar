<?php
include 'header.php';
$id_keranjang = $_GET['id_keranjang'];
$ket = "sls";
$username = $_SESSION['username'];


$query= mysqli_query($link, "SELECT barang.* , keranjang.* FROM keranjang JOIN barang ON barang.id_barang =keranjang.id_barang where username = '$username' AND id_keranjang ='$id_keranjang' "); 
	$row = mysqli_fetch_array($query);


?>

<div class="container">
	<div class="row" style="margin-top: 50px;">
			
		<div class="col-md-12">

			<form action="barang_terima_act.php" method="post">
				<table class="table-bordered" style="padding-top:100;">	
					<tr>
						<th>Id keranjang</th>
						<td><input type="text" name="id" readonly class="form-control" value="<?php echo $row['id_keranjang'];?>"> </td>
					</tr>

					<tr>
						<th>Nama Barang</th>
						
					<td><input type="text" name="" readonly class="form-control" value="<?php echo $row['nama_barang'];?>"> </td>

					
					</tr>
					<tr>
						<th>Jumlah Barang</th>
					
							
					<td><input type="text" name="" readonly class="form-control" value="<?php echo $row['quantity_barang'];?>"> </td>

						
					</tr>
					<tr>
						<th>Harga</th>
					<td><input type="text" name="" readonly class="form-control" value="Rp.<?php echo number_format($row['harga_barang']);?>"> </td>
					</tr>

					<tr>
						<th>Total</th>
					<td><input type="text" name="" readonly class="form-control" value="Rp.<?php echo number_format($row['harga_barang']* $row['quantity_barang']);?>"> </td>
					</tr>


					<tr>
						<th>komentar produk</th>
						<td><input type="text" name="komentar" class="form-control"> </td>
					</tr>
					<tr>
						<td colspan="2">
							<center>
							<input type="submit" Value="Kirim" class="btn btn-danger">
							</center>
						</td>
					</tr>

				</table>

			</form>

		</div>
		