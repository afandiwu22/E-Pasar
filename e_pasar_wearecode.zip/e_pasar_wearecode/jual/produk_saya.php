  <?php include'header.php';?>


    <div class="hero-wrap hero-bread" style="background-image: url('../images/bg_1.jpg');">
      <div class="container">
        <div class="row no-gutters slider-text align-items-center justify-content-center">
          <div class="col-md-9 ftco-animate text-center">
            <h1 class="mb-0 bread">Produk Saya</h1>
          </div>
        </div>
      </div>
    </div>

  <a href="tambah_produk.php" class="btn btn-success" style="margin-top: 10; margin-left:40%; margin-bottom:10px;height: 50px; font-size: 30px;"> <span class="icon icon-plus"></span> Tambah Produk</a>



<div class="container">

<?php 
$username = $_SESSION['username'];
$per_hal=8;
$jumlah_record=mysqli_query($link,"SELECT * from barang where nama_input ='$username'");
$jum = mysqli_num_rows($jumlah_record);

$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>

<form action="cari_produk_saya.php" method="get" style="margin-left: 60%;">
  <div class="input-group col-md-8" >
    <input type="text" class="form-control col-md-6" placeholder="Cari barang ..." aria-describedby="basic-addon1" name="cari">  
    <input type="submit" class="form-control col-md-2" value="Cari" method="get" >



  </div>
</form>



<div class="row">
<?php 

if(isset($_GET['cari'])){
    $cari=mysqli_real_escape_string($link,$_GET['cari']);

    $brg=mysqli_query($link,"select * from barang where nama_barang like '%".$cari."%'   or jenis_barang like '%".$cari."%' or harga_barang like '%".$cari."%' AND nama_input ='$username'  ");
  }else{
    $brg=mysqli_query($link,"select * from barang  where nama_input ='$username'  limit $start, $per_hal");
  }
  $no=1;
    while($b=mysqli_fetch_array($brg)){

    


?>

    		
    			<div class="col-md-6 col-lg-3 ftco-animate">
    				<div class="product">
    					<a href="detail_produk_saya.php?id=<?php echo $b['id_barang']; ?>" class="img-prod"><img class="img-fluid" src="../foto/<?php echo $b['foto_barang']; ?>" >
    						
    					</a>
    					<div class="text py-3 pb-4 px-3 text-center">
    						<h3><a href="#"></a> <?php echo $b['nama_barang'];?> </h3>
    						<div class="d-flex">
    							<div class="pricing">
		    						<p class="price"> Rp.<?php echo number_format($b['harga_barang']);?> ,-</p>
		    					</div>
	    					</div>
	    				

              </div>
    					</div>
    				</div>

              <?php
  } 


  ?>
    			</div>
            </div>






<ul class="pagination">     
      <?php 
      for($x=1;$x<=$halaman;$x++){
        ?>
        <li><a href="?page=<?php echo $x ?>"><?php echo $x ?></a></li>
        <?php
      }
      ?>  
</ul>
</center>






<script type="text/javascript">
    $(document).ready(function(){
      $("#tgl").datepicker({dateFormat : 'yy/mm/dd'});              
    
    

  </script>



  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>



  <script src="../js/jquery.min.js"></script>
  <script src="../js/jquery-migrate-3.0.1.min.js"></script>
  <script src="../js/popper.min.js"></script>
  <script src="../js/bootstrap.min.js"></script>
  <script src="../js/jquery.easing.1.3.js"></script>
  <script src="../js/jquery.waypoints.min.js"></script>
  <script src="../js/jquery.stellar.min.js"></script>
  <script src="../js/owl.carousel.min.js"></script>
  <script src="../js/jquery.magnific-popup.min.js"></script>
  <script src="../js/aos.js"></script>
  <script src="../js/jquery.animateNumber.min.js"></script>
  <script src="../js/bootstrap-datepicker.js"></script>
  <script src="../js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="../js/google-map.js"></script>
  <script src="../js/main.js"></script>
    
  </body>
</html>