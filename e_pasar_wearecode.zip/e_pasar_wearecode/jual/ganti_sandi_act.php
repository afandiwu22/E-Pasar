<?php 
include '../config.php';
$user=$_POST['user'];
$lama=$_POST['lama'];
$baru=$_POST['baru'];
$ulang=$_POST['ulang'];

$cek=mysqli_query($link,"select * from login where password='$lama' and username='$user'");
if(mysqli_num_rows($cek)==1){
	if($baru==$ulang){
		$b =$baru;
		mysqli_query($link,"update login set password='$b' where username='$user'");
		header("location:ganti_sandi.php?pesan=oke");
	}else{
		header("location:ganti_sandi.php?pesan=tdksama");
	}
}else{
	header("location:ganti_sandi.php?pesan=gagal");
}

 ?>