<?php 
$cari=$_GET['cari'];
header("location:riwayat.php?cari=$cari");
?>