  <footer class="ftco-footer ftco-section">
      <div class="container">
        <div class="row">
          <div class="mouse">
            <a href="#" class="mouse-icon">
              <div class="mouse-wheel"><span class="ion-ios-arrow-up"></span></div>
            </a>
          </div>
        </div>
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">E-Pasar</h2>
              <p>Kami membantu anda</p>
              
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Menu</h2>
              <ul class="list-unstyled">
                <li><a href="index.php" class="py-2 d-block">Beranda</a></li>
                <li><a href="produk.php" class="py-2 d-block">Produk</a></li>
                <li><a href="about.php" class="py-2 d-block">Tentang</a></li>
                <li><a href="contact.php" class="py-2 d-block">Kontak</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-4">
        Kami akan menyesuuikan semua keperulan anda.<bR>
             Dengan adanya aplikasi ini, kami bertujuan membantu para perumah tangga untuk mempermudah kesehariannya.   
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Ada Pertanyaan</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">Ruko Fanindo Blok P 10</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">081267714878</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">epasar123.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

            <p><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
              Copyright &copy;<script>document.write(new Date().getFullYear());</script>with <i class="icon-heart color-danger" aria-hidden="true"></i> by <a href="#" target="_blank">E-pasar</a>
              <!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
            </p>
          </div>
        </div>
      </div>
    </footer>
    
  
    
  