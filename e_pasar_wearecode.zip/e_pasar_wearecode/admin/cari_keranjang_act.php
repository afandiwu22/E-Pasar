<?php 
$cari=$_GET['cari'];
header("location:keranjang.php?cari=$cari");
?>