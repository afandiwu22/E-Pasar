<?php 
include '../config.php';
$id=$_GET['id'];
mysqli_query($link,"delete from barang where id_barang='$id'");
header("location:barang.php");

?>