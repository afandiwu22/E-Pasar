<?php 
include '../config.php';
$id=$_GET['id'];
$kep ="acc";

$cek=mysqli_query($link,"update barang SET kep ='$kep' Where id_barang = '$id' ");
if($cek){
	header("location:barang.php?cari=acc");

}

 ?>