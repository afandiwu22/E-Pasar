<!DOCTYPE html>
<html>
<head>
	<?php 
	session_start();
	//include 'cek.php';
	include '../config.php';
	?>
	<title> Admin Panel E-pasar</title>
	  <link rel="shortcut icon" href="../logo/logo.png">
	<link rel="stylesheet" type="text/css" href="../assets/css/bootstrap.css">
	<link rel="stylesheet" type="text/css" href="../assets/js/jquery-ui/jquery-ui.css">
	<script type="text/javascript" src="../assets/js/jquery.js"></script>
	<script type="text/javascript" src="../assets/js/jquery.js"></script>
	<script type="text/javascript" src="../assets/js/bootstrap.js"></script>
	<script type="text/javascript" src="../assets/js/jquery-ui/jquery-ui.js"></script>	
</head>
<body>
	<div class="navbar navbar-default">
		<div class="container-fluid">
			<div class="navbar-header">
             
				<a href="#" class="navbar-brand">Admin Panel</a> 
				<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".navbar-collapse">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</button>
			</div>
			<div class="collapse navbar-collapse">				
				<ul class="nav navbar-nav navbar-right">
					
					<li><a class="dropdown-toggle" data-toggle="dropdown" role="button" href="#">Hy , <?php echo $_SESSION['username']  ?>&nbsp&nbsp<span class="glyphicon glyphicon-user"></span></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="col-md-2">
		<div class="row">
				<div class="col-xs-6 col-md-12">
					<a class="thumbnail">
						<img class="img-responsive" src="../logo/logo.png">
					</a>
				</div>
		
			
		</div>

		<div class="row"></div>
		<ul class="nav nav-pills nav-stacked">
			<li class="active"><a href="#"><span class="glyphicon glyphicon-home"></span> Dashboard</a></li>			
			<li><a href="barang.php"><span class="glyphicon glyphicon-briefcase"></span> Data Barang</a></li>
			<li><a href="keranjang.php"><span class="glyphicon glyphicon-shopping-cart"></span> Data Keranjang</a></li>
			<li><a href="user.php"><span class="glyphicon glyphicon-user"></span> Data Pengguna</a></li>

			<li><a href="ganti_pass.php"><span class="glyphicon glyphicon-lock"></span> Ganti Password</a></li>
			<li><a href="../login/login.php"><span class="glyphicon glyphicon-log-out"></span> Keluar</a></li>			
			
		</ul>
	</div>
	<div class="col-md-10">
	
	
	
	
	
	