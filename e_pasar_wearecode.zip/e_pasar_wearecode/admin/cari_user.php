<?php 
$cari=$_GET['cari'];
header("location:user.php?cari=$cari");
?>