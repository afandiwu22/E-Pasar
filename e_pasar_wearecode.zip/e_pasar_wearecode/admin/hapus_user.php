<?php
include'../config.php';

$id_user = $_GET['id'];
$kosongp = "hapususer00";


$cek = mysqli_query($link, "select * from user where id_user ='$id_user' ");
$row = mysqli_fetch_array($cek);
$username = $row['username'];

	$query = mysqli_query($link, "update user SET password = '$kosongp' Where id_user ='$id_user' ");


	$query = mysqli_query($link, "update login SET password = '$kosongp' Where username ='$username' ");
	header("location:user.php");

?>