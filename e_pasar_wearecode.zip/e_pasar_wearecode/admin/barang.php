<?php
 include 'header_admin.php'; ?>

<h3> <span class="glyphicon glyphicon-briefcase"></span>  Data Barang</h3>

<a href="barang.php">Semua</a> |  <a href="cari_act.php?cari=Proses">Proses</a> | <a href="cari_act.php?cari=acc">Terima</a> | <a href="cari_act.php?cari=tolak">Tolak</a>  | <a href="cari_act.php?cari=habis">Habis</a>  | <a href="cari_act.php?cari=basi">Basi</a> 


<br/>
<br/>

<?php
						$time=mysqli_query($link,"select * from barang where kep ='acc' ");
						$kep_akhir = "basi";
						while($waktu=mysqli_fetch_array($time)){
						$tanggal_input= $waktu['waktu_input']; 
						if($waktu['jenis_barang'] == "Daging"){
							$lama = 7 ;
						}else if($waktu['jenis_barang'] == "Buah"){
							$lama = 49 ;
						}else if($waktu['jenis_barang'] == "Sayur"){
							$lama = 21 ;
						}else if($waktu['jenis_barang'] == "Ikan"){
							$lama = 1 ;
						}else{
							$lama = 147;
						}

$query_update= mysqli_query($link, "update barang SET kep = '$kep_akhir' WHERE DATEDIFF(CURDATE(),tanggal_input) > '$lama' ");				
						
}


$per_hal=10;
$jumlah_record=mysqli_query($link,"SELECT * from barang ");
$jum = mysqli_num_rows($jumlah_record);

$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div class="col-md-12">
	<!-- <a style="margin-bottom:10px" href="lap_barang.php" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>

	-->
</div>
<form action="cari_act.php" method="get">
	<div class="input-group col-md-5 col-md-offset-7">
		<span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-search"></span></span>
		<input type="text" class="form-control" placeholder="Cari barang ...(Nama/Jenis)" aria-describedby="basic-addon1" name="cari">	
		<input type="submit" class="form-control" value="Cari">

	</div>
</form>
<br/>
<?php



?>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-1">Kode</th>
		<th class="col-md-2">Foto Barang</th>
		<th class="col-md-2">Nama Barang</th>
		<th class="col-md-1">Harga</th>
        <th classs="col-md-1"> Stok </th>

        <th classs="col-md-2"> Keputusan </th>

		<!-- <th class="col-md-1">Sisa</th>		 -->
		<th class="col-md-3">Opsi</th>
	</tr>
	<?php 
	
		
		if(isset($_GET['cari'])){
		$cari=mysqli_real_escape_string($link,$_GET['cari']);
		$brg=mysqli_query($link,"select * from barang where nama_barang like '%".$cari."%' or jenis_barang like '%".$cari."%'  or kep = '$cari'");
	}else{
		$brg=mysqli_query($link,"select * from barang  ");
	}

	$ty = mysqli_num_rows($brg);


	

	$no=1;
	if($ty <= 1){
		?>
		<tr>
			<td colspan="8"><center>Tidak ada data</center></td>
		</tr>

		<?php
	}else{

	while($b=mysqli_fetch_array($brg)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['id_barang'] ?></td>
			<td><img src="../foto/<?php echo $b['foto_barang']; ?>" style="width: 50px;"></td>
			<td><?php echo $b['nama_barang'] ?></td>
			<td>Rp.<?php echo number_format($b['harga_barang']) ?>,-</td>
            <td><?php echo $b['quantity_barang'] ?></td>
            <td>
            	<?php 

            	if($b['kep'] =="proses"){

            		?>
            	<a onclick="if(confirm('Apakah anda yakin ingin Menampilkan data Barang ini ??')){ location.href='acc_barang.php?id=<?php echo $b['id_barang']; ?>' }" class="btn btn-success">Terima</a>
            	<a onclick="if(confirm('Apakah anda yakin ingin Menolak Menampilkan Barang ini ??')){ location.href='tolak_barang.php?id=<?php echo $b['id_barang']; ?>' }" class="btn btn-warning">Tolak</a>
<?php
}else{

}
?>
            </td>
			
			<td>
				<a href="det_barang.php?id=<?php echo $b['id_barang']; ?>" class="btn btn-info">Detail</a>
				<a onclick="if(confirm('Apakah anda yakin ingin menghapus data ini ??')){ location.href='hapus.php?id=<?php echo $b['id_barang']; ?>' }" class="btn btn-danger">Hapus</a>
			</td>
		</tr>		
		<?php 
	}
}
	?>

</table>
<ul class="pagination">			
			<?php 
			for($x=1;$x<=$halaman;$x++){
				?>
				<li><a href="?page=<?php echo $x ?>"><?php echo $x ?></a></li>
				<?php
			}
			?>						
		</ul>
<!-- modal input -->
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Barang Baru</h4>
			</div>
			<div class="modal-body">
				<form action="tmb_brg_act.php" method="post">
				
				<div class="form-group">
						<label>kode</label>
						<input name="id" type="text" class="form-control" placeholder="Kode Barang ...">
					</div>
					<div class="form-group">
						<label>Nama Barang</label>
						<input name="nama" type="text" class="form-control" placeholder="Nama Barang ...">
					</div>
					<div class="form-group">
						<label>Series</label>
						<select name="jenis" type="text" class="form-control" >
								
									<option> Legend </option>
									<option>Scoopy </option>
									<option>Sports </option>
								
							</select>
							
					</div>
					<div class="form-group">
							<label>Suplier</label>								
							<select class="form-control" name="suplier">
								<?php 
								$sup=mysqli_query($link,"select * from suplier ");
								while($s=mysqli_fetch_array($sup)){
									?>	
									<option value="<?php echo $s['nama']; ?>"><?php echo $s['nama'] ?></option>
									<?php 
								}
								?>
							</select>

						</div>		
					<div class="form-group">
						<label>Harga Beli</label>
						<input name="modal" type="text" class="form-control" placeholder="Harga Beli ...">
					</div>
					<div class="form-group">
						<label>Harga Jual</label>
						<input name="harga" type="text" class="form-control" placeholder="Harga Jual ...">
					</div>
					

																		
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>

</div>

