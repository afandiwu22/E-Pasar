<?php 
include 'header_admin.php';
?>

<h3><span class="glyphicon glyphicon-shopping-cart"></span>  Detail Keranjang</h3>
<a class="btn" href="keranjang.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>

<?php
$id_keranjang=mysqli_real_escape_string($link,$_GET['id']);


$det=mysqli_query($link," SELECT barang.* , keranjang.* FROM keranjang JOIN barang ON barang.id_barang =keranjang.id_barang  where id_keranjang ='$id_keranjang' ");

while($d=mysqli_fetch_array($det)){
	?>	
	
	<table class="table">
		<tr>
			<td>kode</td>
			<td><?php echo $d['id_keranjang'] ?></td>
		</tr>
		<tr>
			<td>Foto</td>
			<td><img src="../foto/<?php echo $d['foto_barang'] ?>" width="100"></td>
		</tr>
		<tr> 
			<td>Nama</td>
			<td><?php echo $d['nama_barang'] ?></td>
		</tr>
		<tr>
			<td>Jenis</td>
			<td><?php echo $d['jenis_barang'] ?></td>
		</tr>
		<tr>
			<td>Harga</td>
			<td>Rp.<?php echo number_format($d['harga_barang']); ?></td>
		</tr>
			<tr>
			<td>Harga</td>
			<td><?php echo number_format($d['quantity_barang']); ?></td>
		</tr>
		<tr>
			<td>Total</td>
			<td>Rp.<?php 
						echo number_format($d['total_barang']); ?>,- </td>
		</tr>
		
			
		
		<tr>
			<td>Keterangan</td>
			<td><?php 
			 	if($d['ket_k']=="bb"){
			 		echo "Dalam Proess";
			 	}else if($d['ket_k']=="krm"){
			 		echo "Dalam Pengiriman";
			 	}else if($d['ket_k']=="sls"){
			 		echo "Barang Telah Diterima";
			 	}

			 	?>
			 	




			 </td>
		</tr>


		<tr>
			<td>Komentar Pembeli</td>
			<td><?php echo $d['komentar'] ?></td>
		</tr>

		<tr>
			<td>Tanggal Beli</td>
			<td><?php echo $d['tanggal'] ?></td>
		</tr>
	</table>
	<?php 

}

?>