<?php 
include 'header_admin.php';
?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Detail Barang</h3>
<a class="btn" href="barang.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>

<?php
$id_brg=mysqli_real_escape_string($link,$_GET['id']);


$det=mysqli_query($link,"select * from barang where id_barang='$id_brg' ");
while($d=mysqli_fetch_array($det)){
	?>	
	
	<table class="table">
		<tr>
			<td>kode</td>
			<td><?php echo $d['id_barang'] ?></td>
		</tr>
		<tr> 
			<td>Foto</td>
			<td><img src="../foto/<?php echo $d['foto_barang'] ?>" style="width: 100px;" ></td>
		</tr>
		<tr> 
			<td>Nama</td>
			<td><?php echo $d['nama_barang'] ?></td>
		</tr>
		<tr>
			<td>Jenis</td>
			<td><?php echo $d['jenis_barang'] ?></td>
		</tr>
		<tr>
			<td>Quantity</td>
			<td><?php echo $d['quantity_barang'] ?></td>
		</tr>
		<tr>
			<td>Harga</td>
			<td>Rp.<?php 
						echo number_format($d['harga_barang']); ?>,- </td>
		</tr>
		
		
		
		<tr>
			<td>Keterangan</td>
			<td><?php echo $d['ket_barang'] ?></td>
		</tr>

		<tr>
			<td>Waktu Input</td>
			<td><?php echo $d['waktu_input'] ?></td>
		</tr>

		<tr>
			<td>Nama Input</td>
			<td><?php echo $d['nama_input'] ?></td>
		</tr>

		<tr>
			<td>Waktu Edit</td>
			<td>
				<?php IF(!$d['waktu_edit']){
					?> <p style="color: red;"> - </p>
					 <?php

				}else{
					echo $d['waktu_edit'] ;
					
					}
					?>

			</td>
		</tr>
		<tr>
			<td>Nama Edit</td>
			<td>


				<?php IF(!$d['nama_edit']){
					?> <p style="color: red;"> - </p>
					 <?php

				}else{
					echo $d['nama_edit'] ;
					
					}
					?>

				</td>
		</tr>

	</table>
	<?php 

}

?>
