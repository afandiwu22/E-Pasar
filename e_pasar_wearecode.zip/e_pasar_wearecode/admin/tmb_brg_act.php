<?php 
include 'config.php';

$id=$_POST['id'];
$nama=$_POST['nama'];
$jenis=$_POST['jenis'];
$suplier=$_POST['suplier'];
$modal=$_POST['modal'];
$harga=$_POST['harga'];


$query = mysqli_query($link,"insert into barang values('','".$id."','".$nama."','".$jenis."','".$suplier."','".$modal."','".$harga."',0)");
 if($query){
 header("location:barang.php");
 }
 
 ?>
 
 
 