<?php 
include 'config.php';
$no=$_POST['no'];
$id=$_POST['id'];
$nama=$_POST['nama'];
$jenis=$_POST['jenis'];
$suplier=$_POST['suplier'];
$modal=$_POST['modal'];
$harga=$_POST['harga'];
$sisa=$_POST['sisa'];

mysqli_query($link,"update barang set id='$id', nama='$nama', jenis='$jenis', suplier='$suplier', modal='$modal', harga='$harga' where no_data='$no'");
header("location:barang.php");



?>