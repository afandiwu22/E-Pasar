<?php
 include 'header_admin.php'; ?>

<h3> <span class="glyphicon glyphicon-user"></span>  Data Pengguna</h3>

<br/>
<br/>


<?php 

$per_hal=10;
$jumlah_record=mysqli_query($link,"SELECT * from user");
$jum = mysqli_num_rows($jumlah_record);

$halaman=ceil($jum / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div class="col-md-12">
	<!-- <a style="margin-bottom:10px" href="lap_barang.php" target="_blank" class="btn btn-default pull-right"><span class='glyphicon glyphicon-print'></span>  Cetak</a>

	-->
</div>
<form action="cari_act.php" method="get">
	<div class="input-group col-md-5 col-md-offset-7">
		<span class="input-group-addon" id="basic-addon1"><span class="glyphicon glyphicon-search"></span></span>
		<input type="text" class="form-control" placeholder="Cari barang ...(Username/Email)" aria-describedby="basic-addon1" name="cari">	
		<input type="submit" class="form-control" value="Cari">

	</div>
</form>
<br/>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">No</th>
		<th class="col-md-1">Nama</th>
		<th class="col-md-2">Tempat, Tanggal Lahir</th>
		<th class="col-md-2">Nomor Hp</th>
		<th class="col-md-2">Email</th>
        <th classs="col-md-2"> Username </th>
        <th>Aksi</th>
		<!-- <th class="col-md-1">Sisa</th>		 -->
	</tr>
	<?php 
	
		
		
	if(isset($_GET['cari'])){
		$cari=mysqli_real_escape_string($link,$_GET['cari']);
		$brg=mysqli_query($link," SELECT * from user email like '%".$cari."%' or username like '%".$cari."%'  ");
	}else{
		$brg=mysqli_query($link," SELECT * from user ");
	}
	$no=1;
	while($b=mysqli_fetch_array($brg)){

		?>
		<tr>
			<td><?php echo $no++ ?></td>
			<td><?php echo $b['nama'] ?></td>
			<td><?php echo $b['ttl'] ?></td>
			<td><?php echo $b['no_hp'] ?></td>
            <td><?php echo $b['email'] ?></td>
            <td><?php echo $b['username']?>	</td>
            <td>
            	<a href="hapus_user.php?id=<?php echo $b['id_user'];?>" class="btn btn-warning">Hapus</a>
            </td>
					</tr>		
		<?php 
	}
	?>

</table>
<ul class="pagination">			
			<?php 
			for($x=1;$x<=$halaman;$x++){
				?>
				<li><a href="?page=<?php echo $x ?>"><?php echo $x ?></a></li>
				<?php
			}
			?>						
		</ul>


